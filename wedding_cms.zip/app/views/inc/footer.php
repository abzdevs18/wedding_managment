	<script src="<?=URL_ROOT;?>/js/main.js"></script>
	<script src="<?=URL_ROOT;?>/js/animsiton.min.js"></script>
	<script src="<?=URL_ROOT;?>/js/animation.js"></script>
</body>
</html>